"""
Classification / regression model training and evaluation.
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.svm import LinearSVC, LinearSVR
from sklearn.neural_network import MLPClassifier, MLPRegressor
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, roc_auc_score, r2_score, mean_absolute_error,
    mean_squared_error,
)

RANDOM_STATE = 42


def run_classifiers(X_train, X_test, y_train, y_test, positive_label=1):
    """Train RF / DT / LinearSVC / MLP and return a results dict + confusion matrices."""
    models = {
        "Random Forest": RandomForestClassifier(n_estimators=300, random_state=RANDOM_STATE, n_jobs=-1),
        "Decision Tree": DecisionTreeClassifier(random_state=RANDOM_STATE),
        "Linear SVM": LinearSVC(random_state=RANDOM_STATE, max_iter=5000, dual="auto"),
        "MLP": MLPClassifier(random_state=RANDOM_STATE, max_iter=500, early_stopping=True),
    }

    rows = []
    confusions = {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        preds = model.predict(X_test)

        acc = accuracy_score(y_test, preds)
        prec_w = precision_score(y_test, preds, average="weighted", zero_division=0)
        rec_w = recall_score(y_test, preds, average="weighted", zero_division=0)
        f1_w = f1_score(y_test, preds, average="weighted", zero_division=0)

        prec_pos = precision_score(y_test, preds, pos_label=positive_label, zero_division=0)
        rec_pos = recall_score(y_test, preds, pos_label=positive_label, zero_division=0)
        f1_pos = f1_score(y_test, preds, pos_label=positive_label, zero_division=0)

        auc = None
        if hasattr(model, "predict_proba"):
            try:
                proba = model.predict_proba(X_test)[:, 1]
                auc = roc_auc_score(y_test, proba)
            except Exception:
                auc = None
        elif hasattr(model, "decision_function"):
            try:
                scores = model.decision_function(X_test)
                auc = roc_auc_score(y_test, scores)
            except Exception:
                auc = None

        rows.append({
            "Model": name,
            "Accuracy": round(acc, 4),
            "Weighted Precision": round(prec_w, 4),
            "Weighted Recall": round(rec_w, 4),
            "Weighted F1": round(f1_w, 4),
            "Positive-class Precision": round(prec_pos, 4),
            "Positive-class Recall": round(rec_pos, 4),
            "Positive-class F1": round(f1_pos, 4),
            "ROC-AUC": round(auc, 4) if auc is not None else None,
        })
        confusions[name] = confusion_matrix(y_test, preds)

    return pd.DataFrame(rows), confusions


def run_regressors(X_train, X_test, y_train, y_test):
    """Train RF / DT / LinearSVR / MLP regressors and return metrics."""
    models = {
        "Random Forest": RandomForestRegressor(n_estimators=300, random_state=RANDOM_STATE, n_jobs=-1),
        "Decision Tree": DecisionTreeRegressor(random_state=RANDOM_STATE),
        "Linear SVR": LinearSVR(random_state=RANDOM_STATE, max_iter=10000, dual="auto"),
        "MLP": MLPRegressor(random_state=RANDOM_STATE, max_iter=1000, early_stopping=True),
    }

    rows = []
    for name, model in models.items():
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        rows.append({
            "Model": name,
            "R2": round(r2_score(y_test, preds), 4),
            "MAE": round(mean_absolute_error(y_test, preds), 4),
            "RMSE": round(np.sqrt(mean_squared_error(y_test, preds)), 4),
        })

    return pd.DataFrame(rows)


def feature_importance(X_train, y_train, feature_names, top_n=10):
    rf = RandomForestClassifier(n_estimators=300, random_state=RANDOM_STATE, n_jobs=-1)
    rf.fit(X_train, y_train)
    imp = pd.Series(rf.feature_importances_, index=feature_names).sort_values(ascending=False)
    return imp.head(top_n)
