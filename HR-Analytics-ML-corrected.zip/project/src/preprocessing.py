"""
Preprocessing module for the four HR / Green-HRM datasets used in the thesis.

Each `load_and_prepare_*` function returns:
    X_train, X_test, y_train, y_test, feature_names, missing_report (DataFrame)

Missing-value statistics and encoders/scalers are always fit on the
TRAINING split only, then applied to the test split, to avoid leakage.
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder

RANDOM_STATE = 42


def _missing_report(df: pd.DataFrame) -> pd.DataFrame:
    miss = df.isna().sum()
    miss = miss[miss > 0].sort_values(ascending=False)
    pct = (miss / len(df) * 100).round(2)
    return pd.DataFrame({"missing_count": miss, "missing_pct": pct})


def load_ibm(path="data/WA_Fn-UseC_-HR-Employee-Attrition.csv"):
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]

    y = (df["Attrition"] == "Yes").astype(int)
    drop_cols = ["Attrition", "EmployeeCount", "EmployeeNumber", "Over18", "StandardHours"]
    X = df.drop(columns=[c for c in drop_cols if c in df.columns])

    missing_report = _missing_report(X)

    cat_cols = X.select_dtypes(include="object").columns.tolist()
    num_cols = [c for c in X.columns if c not in cat_cols]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE
    )

    ohe = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    ohe.fit(X_train[cat_cols])
    scaler = StandardScaler()
    scaler.fit(X_train[num_cols])

    def transform(Xd):
        cat_arr = ohe.transform(Xd[cat_cols])
        num_arr = scaler.transform(Xd[num_cols])
        cat_names = ohe.get_feature_names_out(cat_cols)
        out = pd.DataFrame(
            np.hstack([num_arr, cat_arr]),
            columns=list(num_cols) + list(cat_names),
            index=Xd.index,
        )
        return out

    X_train_t = transform(X_train)
    X_test_t = transform(X_test)

    return X_train_t, X_test_t, y_train, y_test, X_train_t.columns.tolist(), missing_report


def load_job_change(path="data/aug_train.csv"):
    df = pd.read_csv(path)
    y = df["target"].astype(int)
    X = df.drop(columns=["target", "enrollee_id"])

    missing_report = _missing_report(X)

    cat_cols = X.select_dtypes(include="object").columns.tolist()
    num_cols = [c for c in X.columns if c not in cat_cols]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE
    )

    # impute categorical with train-mode, numeric with train-median
    modes = X_train[cat_cols].mode().iloc[0]
    medians = X_train[num_cols].median()

    def impute(Xd):
        Xd = Xd.copy()
        for c in cat_cols:
            Xd[c] = Xd[c].fillna(modes[c])
        for c in num_cols:
            Xd[c] = Xd[c].fillna(medians[c])
        return Xd

    X_train_i = impute(X_train)
    X_test_i = impute(X_test)

    ohe = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    ohe.fit(X_train_i[cat_cols])
    scaler = StandardScaler()
    scaler.fit(X_train_i[num_cols])

    def transform(Xd):
        cat_arr = ohe.transform(Xd[cat_cols])
        num_arr = scaler.transform(Xd[num_cols])
        cat_names = ohe.get_feature_names_out(cat_cols)
        out = pd.DataFrame(
            np.hstack([num_arr, cat_arr]),
            columns=list(num_cols) + list(cat_names),
            index=Xd.index,
        )
        return out

    X_train_t = transform(X_train_i)
    X_test_t = transform(X_test_i)

    return X_train_t, X_test_t, y_train, y_test, X_train_t.columns.tolist(), missing_report


def load_promotion(path="data/train_LZdllcl.csv"):
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]
    y = df["is_promoted"].astype(int)
    X = df.drop(columns=["is_promoted", "employee_id"])

    missing_report = _missing_report(X)

    cat_cols = X.select_dtypes(include="object").columns.tolist()
    num_cols = [c for c in X.columns if c not in cat_cols]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE
    )

    mode_education = X_train["education"].mode().iloc[0]
    median_rating = X_train["previous_year_rating"].median()

    def impute(Xd):
        Xd = Xd.copy()
        Xd["education"] = Xd["education"].fillna(mode_education)
        Xd["previous_year_rating"] = Xd["previous_year_rating"].fillna(median_rating)
        return Xd

    X_train_i = impute(X_train)
    X_test_i = impute(X_test)

    ohe = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    ohe.fit(X_train_i[cat_cols])
    scaler = StandardScaler()
    scaler.fit(X_train_i[num_cols])

    def transform(Xd):
        cat_arr = ohe.transform(Xd[cat_cols])
        num_arr = scaler.transform(Xd[num_cols])
        cat_names = ohe.get_feature_names_out(cat_cols)
        out = pd.DataFrame(
            np.hstack([num_arr, cat_arr]),
            columns=list(num_cols) + list(cat_names),
            index=Xd.index,
        )
        return out

    X_train_t = transform(X_train_i)
    X_test_t = transform(X_test_i)

    return X_train_t, X_test_t, y_train, y_test, X_train_t.columns.tolist(), missing_report


# --- GHRM survey dataset (construct scores, from Adu Sarfo et al. 2024) ---
CONSTRUCT_ITEMS = {
    "GRS": ["GRS1", "GRS2", "GRS3", "GRS4"],
    "GTD": ["GTD1", "GTD2", "GDT3", "GTD4", "GTD5"],   # 'GDT3' is the source file's own header spelling
    "GPA": ["GPA1", "GPA2", "GPA3", "GPA4", "GPA5", "GPA6"],
    "GCM": ["GCM1", "GCM2", "GCM3", "GCM4"],
    "GEE": ["GEE1", "GEE4", "GEE5", "GEE6"],
    "FEP": ["FEP1", "FEP5", "FEP7", "FEP9"],
}


def load_ghrm(path="data/HRM_DATASETS.csv"):
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]

    constructs = pd.DataFrame(index=df.index)
    for name, items in CONSTRUCT_ITEMS.items():
        items_present = [c for c in items if c in df.columns]
        constructs[name] = df[items_present].astype(float).mean(axis=1)

    missing_report = _missing_report(constructs)
    constructs = constructs.dropna()

    median_fep = constructs["FEP"].median()
    y = (constructs["FEP"] > median_fep).astype(int)
    X = constructs[["GRS", "GTD", "GPA", "GCM", "GEE"]]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE
    )

    scaler = StandardScaler()
    scaler.fit(X_train)
    X_train_t = pd.DataFrame(scaler.transform(X_train), columns=X.columns, index=X_train.index)
    X_test_t = pd.DataFrame(scaler.transform(X_test), columns=X.columns, index=X_test.index)

    return X_train_t, X_test_t, y_train, y_test, X_train_t.columns.tolist(), missing_report, constructs, median_fep
