"""
Runs the full Chapter-4 analysis across all four datasets and writes
results to results/*.csv and results/summary_report.md.

Usage: python src/run_analysis.py   (run from the project root)
"""

import os
import sys
import pandas as pd

sys.path.insert(0, os.path.dirname(__file__))
import preprocessing as prep
import models
import clustering

RESULTS_DIR = os.path.join(os.path.dirname(__file__), "..", "results")
os.makedirs(RESULTS_DIR, exist_ok=True)


def save(df, name):
    path = os.path.join(RESULTS_DIR, name)
    df.to_csv(path, index=False)
    print(f"  -> saved {path}")


def section(title):
    print("\n" + "=" * 70)
    print(title)
    print("=" * 70)


def main():
    report_lines = ["# Chapter 4 analysis results (verified run)\n"]

    # ---------------- IBM HR Attrition ----------------
    section("IBM HR Employee Attrition")
    Xtr, Xte, ytr, yte, feats, miss = prep.load_ibm()
    print("Missing values:\n", miss)
    save(miss.reset_index().rename(columns={"index": "variable"}), "ibm_missing.csv")

    clf_results, confusions = models.run_classifiers(Xtr, Xte, ytr, yte)
    print(clf_results)
    save(clf_results, "ibm_classification.csv")
    for name, cm in confusions.items():
        print(f"Confusion matrix ({name}):\n{cm}")

    imp = models.feature_importance(Xtr, ytr, feats)
    print("Top features (RF):\n", imp)
    save(imp.reset_index().rename(columns={"index": "feature", 0: "importance"}), "ibm_feature_importance.csv")

    ibm_clust_summary, ibm_best_k, ibm_fitted = clustering.select_k(Xtr)
    print("K-Means summary:\n", ibm_clust_summary, "\nbest k =", ibm_best_k)
    save(ibm_clust_summary, "ibm_kmeans_summary.csv")

    report_lines.append("## IBM HR Employee Attrition (n=1,470)\n")
    report_lines.append(clf_results.to_markdown(index=False))
    report_lines.append(f"\nBest K-Means k = **{ibm_best_k}**, "
                         f"silhouette = **{ibm_clust_summary.loc[ibm_clust_summary['k']==ibm_best_k,'Silhouette'].values[0]}**\n")

    # ---------------- Job Change ----------------
    section("HR Analytics: Job Change of Data Scientists")
    Xtr2, Xte2, ytr2, yte2, feats2, miss2 = prep.load_job_change()
    print("Missing values:\n", miss2)
    save(miss2.reset_index().rename(columns={"index": "variable"}), "jobchange_missing.csv")

    clf_results2, confusions2 = models.run_classifiers(Xtr2, Xte2, ytr2, yte2)
    print(clf_results2)
    save(clf_results2, "jobchange_classification.csv")

    imp2 = models.feature_importance(Xtr2, ytr2, feats2)
    save(imp2.reset_index().rename(columns={"index": "feature", 0: "importance"}), "jobchange_feature_importance.csv")

    jc_clust_summary, jc_best_k, jc_fitted = clustering.select_k(Xtr2)
    print("K-Means summary:\n", jc_clust_summary, "\nbest k =", jc_best_k)
    save(jc_clust_summary, "jobchange_kmeans_summary.csv")

    report_lines.append("## HR Analytics: Job Change of Data Scientists (n=19,158)\n")
    report_lines.append(clf_results2.to_markdown(index=False))
    report_lines.append(f"\nBest K-Means k = **{jc_best_k}**, "
                         f"silhouette = **{jc_clust_summary.loc[jc_clust_summary['k']==jc_best_k,'Silhouette'].values[0]}**\n")

    # ---------------- Employee Promotion ----------------
    section("Employee Promotion Prediction")
    Xtr3, Xte3, ytr3, yte3, feats3, miss3 = prep.load_promotion()
    print("Missing values:\n", miss3)
    save(miss3.reset_index().rename(columns={"index": "variable"}), "promotion_missing.csv")

    clf_results3, confusions3 = models.run_classifiers(Xtr3, Xte3, ytr3, yte3)
    print(clf_results3)
    save(clf_results3, "promotion_classification.csv")

    imp3 = models.feature_importance(Xtr3, ytr3, feats3)
    save(imp3.reset_index().rename(columns={"index": "feature", 0: "importance"}), "promotion_feature_importance.csv")

    prom_clust_summary, prom_best_k, prom_fitted = clustering.select_k(Xtr3)
    print("K-Means summary:\n", prom_clust_summary, "\nbest k =", prom_best_k)
    save(prom_clust_summary, "promotion_kmeans_summary.csv")

    report_lines.append("## Employee Promotion Prediction (n=54,808)\n")
    report_lines.append(clf_results3.to_markdown(index=False))
    report_lines.append(f"\nBest K-Means k = **{prom_best_k}**, "
                         f"silhouette = **{prom_clust_summary.loc[prom_clust_summary['k']==prom_best_k,'Silhouette'].values[0]}**\n")

    # ---------------- GHRM survey dataset ----------------
    section("GHRM–Environmental Performance survey (Adu Sarfo et al. 2024)")
    Xtr4, Xte4, ytr4, yte4, feats4, miss4, constructs, median_fep = prep.load_ghrm()
    print("Missing values (construct level):\n", miss4)
    save(miss4.reset_index().rename(columns={"index": "construct"}), "ghrm_missing.csv")
    print(f"FEP median split value = {median_fep}")

    clf_results4, confusions4 = models.run_classifiers(Xtr4, Xte4, ytr4, yte4)
    print(clf_results4)
    save(clf_results4, "ghrm_classification.csv")

    imp4 = models.feature_importance(Xtr4, ytr4, feats4)
    print("Feature importance (all 5 constructs):\n", imp4)
    save(imp4.reset_index().rename(columns={"index": "construct", 0: "importance"}), "ghrm_feature_importance.csv")

    ghrm_clust_summary, ghrm_best_k, ghrm_fitted = clustering.select_k(Xtr4)
    print("K-Means summary:\n", ghrm_clust_summary, "\nbest k =", ghrm_best_k)
    save(ghrm_clust_summary, "ghrm_kmeans_summary.csv")

    report_lines.append("## GHRM–Environmental Performance survey (n=320)\n")
    report_lines.append(clf_results4.to_markdown(index=False))
    report_lines.append(f"\nBest K-Means k = **{ghrm_best_k}**, "
                         f"silhouette = **{ghrm_clust_summary.loc[ghrm_clust_summary['k']==ghrm_best_k,'Silhouette'].values[0]}**\n")

    with open(os.path.join(RESULTS_DIR, "summary_report.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(report_lines))

    print("\nAll results written to results/")


if __name__ == "__main__":
    main()
