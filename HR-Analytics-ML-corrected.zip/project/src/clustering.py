"""
K-Means clustering with k selection via Silhouette / Davies-Bouldin / SSE.
"""

import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, davies_bouldin_score

RANDOM_STATE = 42


def select_k(X, k_range=range(2, 8)):
    """Run K-Means for each k in k_range, return a summary DataFrame and fitted models."""
    rows = []
    fitted = {}
    for k in k_range:
        km = KMeans(n_clusters=k, random_state=RANDOM_STATE, n_init=10)
        labels = km.fit_predict(X)
        sse = km.inertia_
        sil = silhouette_score(X, labels)
        db = davies_bouldin_score(X, labels)
        rows.append({"k": k, "SSE": round(sse, 2), "Silhouette": round(sil, 4), "Davies-Bouldin": round(db, 4)})
        fitted[k] = (km, labels)

    summary = pd.DataFrame(rows)
    best_k = int(summary.loc[summary["Silhouette"].idxmax(), "k"])
    return summary, best_k, fitted
