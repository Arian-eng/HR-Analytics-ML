# HR Analytics ML

Machine-learning analysis for the master's thesis on Green HRM and HR analytics.

## Scope

The project analyzes **four** datasets:

1. **IBM HR Employee Attrition & Performance** — 1,470 records, target: `Attrition` (binary classification)
2. **HR Analytics: Job Change of Data Scientists** — 19,158 records, target: `target` (binary classification)
3. **Employee Promotion Prediction** — 54,808 records, target: `is_promoted` (binary classification)
4. **GHRM–Environmental Performance survey** (Adu Sarfo et al., 2024, PLOS ONE) — 320 respondents, direct
   Likert-scale Green HRM constructs (GRS, GTD, GPA, GCM, GEE) with `FEP` (Firm Environmental Performance,
   median-split) as the classification target

The first three are general public HR datasets and do not directly measure Green HRM practices; their
outputs are interpreted as HR-performance/behavioral proxy indicators. The fourth dataset provides direct,
validated Green HRM measures and is analyzed separately.

The analysis includes preprocessing (train-only imputation/encoding/scaling to avoid leakage), K-Means
clustering (k = 2..7, selected by Silhouette score), and four supervised models — Random Forest, Decision
Tree, Linear SVM, and a Multilayer Perceptron — evaluated with Accuracy, weighted and positive-class
Precision/Recall/F1, ROC-AUC, and confusion matrices. All four datasets are analyzed independently; no
records are merged across datasets.

## Project structure

```text
HR-Analytics-ML/
├── data/                  # Local datasets (not committed; see .gitignore)
├── src/
│   ├── preprocessing.py   # Per-dataset loading, cleaning, train-only imputation/encoding/scaling
│   ├── models.py          # Classifier/regressor training + evaluation + feature importance
│   ├── clustering.py      # K-Means with k selection (Silhouette / Davies-Bouldin / SSE)
│   └── run_analysis.py    # Orchestrates the full run and writes results/
├── results/                # Generated CSV tables + summary_report.md (this run's output)
├── figures/                 # (reserved for generated charts)
├── validation/
│   └── validation_report.md
├── requirements.txt
├── .gitignore
└── README.md
```

## Reproducibility

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
# place the four CSVs under data/ (see filenames in src/preprocessing.py)
python src/run_analysis.py
```

All train/test splits use `random_state=42`, an 80/20 stratified holdout, and preprocessing fit on the
training split only. Results are written to `results/*.csv` and `results/summary_report.md`.

## Data

The repository intentionally does not include raw datasets unless their redistribution license permits
it. Expected filenames:

- `data/WA_Fn-UseC_-HR-Employee-Attrition.csv`
- `data/aug_train.csv`
- `data/train_LZdllcl.csv`
- `data/HRM_DATASETS.csv`

## Status

The pipeline has been run end-to-end on all four real datasets; see `validation/validation_report.md` and
`results/summary_report.md` for the current verified numbers. These are the authoritative source for
Chapter 4 tables — any numbers in the thesis document should match this run.
