# Chapter 4 validation report

Date: 2026-08-21 (replaces the 2026-08-15 report, which used the superseded
3-dataset framework and a separate "Employee Performance and Productivity"
file — that file is not a real independent dataset; its target column
`KPIs_met_more_than_80` is one field inside `train_LZdllcl.csv`, the real
Employee Promotion Prediction dataset. This report uses the corrected,
4-dataset framework end-to-end.)

## Dataset checks

| Dataset | Rows | Columns | Target | Status |
|---|---:|---:|---|---|
| IBM HR Employee Attrition | 1,470 | 35 | `Attrition` | Valid |
| HR Analytics: Job Change of Data Scientists | 19,158 | 14 | `target` | Valid |
| Employee Promotion Prediction | 54,808 | 14 | `is_promoted` | Valid |
| GHRM–Environmental Performance survey (Adu Sarfo et al., 2024) | 320 | 6 constructs | `FEP` (median split) | Valid |

All four datasets are analyzed independently; results are never merged or pooled across datasets.

## Model benchmark (80/20 stratified holdout, `random_state=42`, preprocessing fit on train only)

### IBM HR Employee Attrition (n=1,470)

| Model | Accuracy | Weighted F1 | Positive-class Recall | Positive-class F1 | ROC-AUC |
|---|---:|---:|---:|---:|---:|
| Random Forest | 0.8503 | 0.8090 | 0.1489 | 0.2414 | 0.8008 |
| Decision Tree | 0.7653 | 0.7749 | 0.3830 | 0.3429 | 0.6105 |
| Linear SVM | 0.8639 | 0.8438 | 0.3191 | 0.4286 | 0.8070 |
| MLP | 0.8741 | 0.8521 | 0.3191 | 0.4478 | 0.7802 |

Attrition is imbalanced (83.9% No / 16.1% Yes), so accuracy alone is misleading — positive-class
recall/F1 are reported alongside it. MLP gives the most balanced result overall; Random Forest has
the highest accuracy but the weakest positive-class recall.

### HR Analytics: Job Change of Data Scientists (n=19,158)

| Model | Accuracy | Weighted F1 | Positive-class Recall | Positive-class F1 | ROC-AUC |
|---|---:|---:|---:|---:|---:|
| Random Forest | 0.7693 | 0.7566 | 0.4052 | 0.4668 | 0.7779 |
| Decision Tree | 0.7129 | 0.7127 | 0.4220 | 0.4229 | 0.6194 |
| Linear SVM | 0.7784 | 0.7606 | 0.3770 | 0.4589 | 0.7932 |
| MLP | 0.7844 | 0.7706 | 0.4178 | 0.4914 | 0.8003 |

### Employee Promotion Prediction (n=54,808)

| Model | Accuracy | Weighted F1 | Positive-class Recall | Positive-class F1 | ROC-AUC |
|---|---:|---:|---:|---:|---:|
| Random Forest | 0.9333 | 0.9185 | 0.2880 | 0.4240 | 0.8837 |
| Decision Tree | 0.8996 | 0.9013 | 0.4507 | 0.4334 | 0.6961 |
| Linear SVM | 0.9332 | 0.9139 | 0.2281 | 0.3679 | 0.8587 |
| MLP | 0.9413 | 0.9283 | 0.3351 | 0.4933 | 0.8993 |

Only 8.5% of records are promoted, so the ~93% accuracy figures are misleading on their own;
positive-class recall (23–45%) shows the real difficulty of this prediction problem.

### GHRM–Environmental Performance survey (n=320)

| Model | Accuracy | Weighted F1 | Positive-class Recall | Positive-class F1 | ROC-AUC |
|---|---:|---:|---:|---:|---:|
| Random Forest | 0.7031 | 0.7045 | 0.6087 | 0.5957 | 0.7800 |
| Decision Tree | 0.7031 | 0.7080 | 0.6957 | 0.6275 | 0.7041 |
| Linear SVM | 0.7344 | 0.7356 | 0.6522 | 0.6383 | 0.8165 |
| MLP | 0.7031 | 0.6980 | 0.5217 | 0.5581 | 0.7794 |

RF feature importance for predicting FEP level: GPA (0.231) > GRS (0.208) ≈ GTD (0.207) > GCM (0.185)
> GEE (0.170).

## K-Means clustering (k = 2..7, best k by Silhouette score)

| Dataset | Best k | Silhouette | Davies-Bouldin |
|---|---:|---:|---:|
| IBM HR Employee Attrition | 2 | 0.1287 | 2.6363 |
| Job Change | 2 | 0.1501 | 2.2730 |
| Employee Promotion | 5 | 0.1506 | 1.7886 |
| GHRM survey | 2 | 0.4239 | 0.8914 |

Full k=2..7 sweeps for all four datasets are in `results/*_kmeans_summary.csv`. Note that Job Change's
silhouette is close between k=2 (0.1501) and k=3 (0.1482) — both are reasonable readings and should be
discussed as such rather than treated as a single sharp optimum.

## Methodological notes

- The three general HR datasets do not contain direct Green HRM measures; their outputs should be
  described as HR-performance/behavioral proxy indicators, not direct GHRM measurement.
- The GHRM survey dataset provides genuine, validated Green HRM constructs and is analyzed on its own
  terms (construct scores, median-split FEP target), not merged with the other three.
- All numbers in this report come from a single, reproducible run of `src/run_analysis.py` against the
  four CSVs listed above. Any number appearing in the thesis Chapter 4 tables should match this report —
  if it doesn't, re-run the pipeline rather than hand-editing a table.

## Superseded

The 2026-08-15 report (three datasets including a separate "Employee Performance and Productivity"
file) is superseded by this report and should not be used as a source for thesis numbers.
