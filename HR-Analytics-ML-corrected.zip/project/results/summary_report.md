# Chapter 4 analysis results (verified run)

## IBM HR Employee Attrition (n=1,470)

| Model         |   Accuracy |   Weighted Precision |   Weighted Recall |   Weighted F1 |   Positive-class Precision |   Positive-class Recall |   Positive-class F1 |   ROC-AUC |
|:--------------|-----------:|---------------------:|------------------:|--------------:|---------------------------:|------------------------:|--------------------:|----------:|
| Random Forest |     0.8503 |               0.8231 |            0.8503 |        0.809  |                     0.6364 |                  0.1489 |              0.2414 |    0.8008 |
| Decision Tree |     0.7653 |               0.7865 |            0.7653 |        0.7749 |                     0.3103 |                  0.383  |              0.3429 |    0.6105 |
| Linear SVM    |     0.8639 |               0.8452 |            0.8639 |        0.8438 |                     0.6522 |                  0.3191 |              0.4286 |    0.807  |
| MLP           |     0.8741 |               0.8619 |            0.8741 |        0.8521 |                     0.75   |                  0.3191 |              0.4478 |    0.7802 |

Best K-Means k = **2**, silhouette = **0.1287**

## HR Analytics: Job Change of Data Scientists (n=19,158)

| Model         |   Accuracy |   Weighted Precision |   Weighted Recall |   Weighted F1 |   Positive-class Precision |   Positive-class Recall |   Positive-class F1 |   ROC-AUC |
|:--------------|-----------:|---------------------:|------------------:|--------------:|---------------------------:|------------------------:|--------------------:|----------:|
| Random Forest |     0.7693 |               0.7517 |            0.7693 |        0.7566 |                     0.5505 |                  0.4052 |              0.4668 |    0.7779 |
| Decision Tree |     0.7129 |               0.7125 |            0.7129 |        0.7127 |                     0.4238 |                  0.422  |              0.4229 |    0.6194 |
| Linear SVM    |     0.7784 |               0.7581 |            0.7784 |        0.7606 |                     0.5863 |                  0.377  |              0.4589 |    0.7932 |
| MLP           |     0.7844 |               0.7674 |            0.7844 |        0.7706 |                     0.5964 |                  0.4178 |              0.4914 |    0.8003 |

Best K-Means k = **2**, silhouette = **0.1501**

## Employee Promotion Prediction (n=54,808)

| Model         |   Accuracy |   Weighted Precision |   Weighted Recall |   Weighted F1 |   Positive-class Precision |   Positive-class Recall |   Positive-class F1 |   ROC-AUC |
|:--------------|-----------:|---------------------:|------------------:|--------------:|---------------------------:|------------------------:|--------------------:|----------:|
| Random Forest |     0.9333 |               0.926  |            0.9333 |        0.9185 |                     0.803  |                  0.288  |              0.424  |    0.8837 |
| Decision Tree |     0.8996 |               0.9032 |            0.8996 |        0.9013 |                     0.4172 |                  0.4507 |              0.4334 |    0.6961 |
| Linear SVM    |     0.9332 |               0.9344 |            0.9332 |        0.9139 |                     0.9509 |                  0.2281 |              0.3679 |    0.8587 |
| MLP           |     0.9413 |               0.9409 |            0.9413 |        0.9283 |                     0.9343 |                  0.3351 |              0.4933 |    0.8993 |

Best K-Means k = **5**, silhouette = **0.1506**

## GHRM–Environmental Performance survey (n=320)

| Model         |   Accuracy |   Weighted Precision |   Weighted Recall |   Weighted F1 |   Positive-class Precision |   Positive-class Recall |   Positive-class F1 |   ROC-AUC |
|:--------------|-----------:|---------------------:|------------------:|--------------:|---------------------------:|------------------------:|--------------------:|----------:|
| Random Forest |     0.7031 |               0.7061 |            0.7031 |        0.7045 |                     0.5833 |                  0.6087 |              0.5957 |    0.78   |
| Decision Tree |     0.7031 |               0.7214 |            0.7031 |        0.708  |                     0.5714 |                  0.6957 |              0.6275 |    0.7041 |
| Linear SVM    |     0.7344 |               0.7371 |            0.7344 |        0.7356 |                     0.625  |                  0.6522 |              0.6383 |    0.8165 |
| MLP           |     0.7031 |               0.6961 |            0.7031 |        0.698  |                     0.6    |                  0.5217 |              0.5581 |    0.7794 |

Best K-Means k = **2**, silhouette = **0.4239**
